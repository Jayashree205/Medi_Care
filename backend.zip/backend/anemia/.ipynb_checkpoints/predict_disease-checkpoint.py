import joblib

# Load the trained model and vectorizer
model = joblib.load("auto_model.pkl")
vectorizer = joblib.load("vectorizer.pkl")

def predict_disease(symptoms):
    symptoms_vectorized = vectorizer.transform([symptoms])
    prediction = model.predict(symptoms_vectorized)
    return prediction[0]

# Example usage
if __name__ == "__main__":
    user_input = input("Enter symptoms (comma-separated): ")
    predicted_disease = predict_disease(user_input)
    print(f"🩺 Predicted Disease: {predicted_disease}")
