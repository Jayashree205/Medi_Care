import joblib
import pandas as pd

# Load the trained model and vectorizer
model = joblib.load("auto_model.pkl")
vectorizer = joblib.load("vectorizer.pkl")
df = pd.read_csv("C:/Users/SRIDEEPALAKSHMI/medi-care/diabetesdiabetes_data_upload.csv")

def predict_disease(symptoms):
    symptoms_vectorized = vectorizer.transform([symptoms])
    prediction = model.predict(symptoms_vectorized)
    return prediction[0]

def get_suggestion(predicted_disease):
    suggestion = df[df["Disease"] == predicted_disease]["Suggestion"].values
    return suggestion[0] if len(suggestion) > 0 else "No suggestion available."

# Run the system
if __name__ == "__main__":
    user_input = input("Enter symptoms (comma-separated): ")
    predicted_disease = predict_disease(user_input)
    treatment_suggestion = get_suggestion(predicted_disease)

    print(f"🩺 Predicted Disease: {predicted_disease}")
    print(f"💊 Suggested Treatment: {treatment_suggestion}")
